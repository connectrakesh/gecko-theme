Dear customer,

Thank you so much for choose us, to start with Boutique, you need

1 - Upload theme file Gecko*.*.*.zip to your Shopify store
2 - Open document folder and check our guide (we will update it every day) or follow from our website: https://wiki.the4.co

If you have any problem, I hope you can send us a email to: the4studio.net@gmail.com or our forum: https://support.the4.co

We will try our best to answer your email / forum as soon as possible, I hope you won't give us bad review.

Thank you for choosing us

Kind Regard


-----------------------------------

Update
To update, please see this video tutorial: https://www.youtube.com/watch?v=3TbYN8RtvDI&list=PLA7nTzZdSen2OakP6oPNkMQk6YK__Y5j4&index=15


-----------------------------------



Change Log

https://gecko5-docs.the4.co/changelog